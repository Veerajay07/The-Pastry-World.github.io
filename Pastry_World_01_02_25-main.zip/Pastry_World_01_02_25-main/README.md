# Pastry_World_01_02_25
Learn how to create a stunning and responsive coffee/cafe website using HTML, CSS, and JavaScript in this step-by-step tutorial!

![96-1](https://github.com/user-attachments/assets/1e0c5be6-d521-461e-b50f-2b2bb1eed614)

